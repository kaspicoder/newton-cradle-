class Ball extends BaseClass {
    constructor(x,y){
      super(x,y,50,50);
      this.image = loadImage("ball.jpg");
    }
  
    display() {
      
      super.display();
    }
  }
  